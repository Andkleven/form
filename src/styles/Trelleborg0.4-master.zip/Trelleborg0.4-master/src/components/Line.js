import React from "react";

export default () => {
  return (
    <>
      <hr className="w-100 mt-0 mb-1 p-0" />
      <br />
    </>
  );
};
