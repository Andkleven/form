import React from "react";

const Home = () => <div />;

export default Home;
