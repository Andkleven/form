export const AUTH_TOKEN = "auth-token";
